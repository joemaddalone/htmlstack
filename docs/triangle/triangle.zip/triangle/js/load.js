function inc(jspath) {
    document.write('<script type="text/javascript" src="' + jspath + '"><\/script>');
}
inc("js/inserttitle.js");
inc("js/compiled.js");



